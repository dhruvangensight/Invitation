<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Product;
use \App\Company;
use DB;
use PDF;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __constructor(){
        $this->middleware('auth');    
    } 

    public function index()
    {
        $product = Product::orderBy('created_at', 'desc')->paginate(15);
        return view('product.index', compact('product'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $companies = Company::pluck('id','name');
        return view('product.create',compact('companies'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = request()->validate([
            'company_id' => ['required'],
            'name' => ['required','min:3'],
            'description' => ['required','min:3'],
            'model' => ['required','min:3'],
            'price' => ['required','numeric'],
            'quantity' => ['required','numeric', 'integer'],
        ]);
        Product::create($validated);
        return redirect('/product');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $companies = Company::pluck('id','name');
        
        $product = Product::find($id);
        return view('product.update', compact('product','companies'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Product $product)
    {
        $validated = request()->validate([
            'company_id' => ['required'],
            'name' => ['required','min:3'],
            'description' => ['required','min:3'],
            'model' => ['required','min:3'],
            'price' => ['required','numeric'],
            'quantity' => ['required','numeric', 'integer'],
        ]);
        $product->update($validated);
        return redirect('/product');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        $product->delete();
        return redirect('/product');
    }

    public function filter(Product $product){
        $query = Product::select('*');
        $query = is_null(request('name')) ? $query : $query->where('name', 'LIKE', "%%".request('name')."%%");
        $query = is_null(request('model')) ? $query : $query->where('model', 'LIKE', "%%".request('model')."%%");

        $query = is_null(request('price_min')) ? $query : $query->where('price', '>=', request('price_min'));
        $query = is_null(request('price_max')) ? $query : $query->where('price', '<=', request('price_max'));

        $query = is_null(request('qty_min')) ? $query : $query->where('quantity', '>=', request('qty_min'));
        $query = is_null(request('qty_max')) ? $query : $query->where('quantity', '<=', request('qty_max'));

        try {
            $product = $query->paginate(10);
        } catch (Exception $e) {
            report($e);
            return false;
        }

        //return $product = $query->paginate(10);

        return view('product.index', compact('product'));
    }

    public function pdf(){  
        set_time_limit(0);  
        $products = Product::get();
        //return view('product.export', compact('products'));
        $pdf = PDF::loadView('product.export', compact('products'));
        //$pdf->save(storage_path().'/products.pdf'); To save PDF on Server
        $pdf->download('products.pdf');
        return redirect('/product');
    }


}
