<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    public static function customerCount(){
        return static::all()->count();
    }

    protected $fillable = [
        'name', 'email', 'phone', 'address', 'notes'
    ];
}
