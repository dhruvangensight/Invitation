<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public function company()
    {
        return $this->belongsTo('App\Company', 'company_id');
    }

    public static function productCount(){
        return static::all()->count();
    }

    protected $fillable = [
        'name', 'description','model','price','quantity','company_id'
    ];
}
