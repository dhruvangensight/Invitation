<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    public function products()
    {
        return $this->hasMany('App\Products', 'company_id');
    }

    public static function companyCount(){
        return static::all()->count();
    }

    protected $fillable = [
        'name', 'description'
    ];
}
