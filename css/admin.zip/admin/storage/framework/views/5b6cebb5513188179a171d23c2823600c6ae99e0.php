<?php echo e($slot); ?>


<?php /* E:\xampp\htdocs\laravel\admin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php */ ?>