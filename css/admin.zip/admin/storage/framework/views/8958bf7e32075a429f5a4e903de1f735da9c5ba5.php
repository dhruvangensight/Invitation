<?php $__env->startSection('section-title', 'Companies'); ?>

<?php $__env->startSection('section-button'); ?>
    <a class="btn btn-sm btn-outline-secondary" href="/company/create">
        Add new
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md">
            <table class="table table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($c->name); ?></td>
                            <td><?php echo $c->description; ?></td>
                            <td>
                                <a class="btn btn-secondary btn-sm" href="/company/<?php echo e($c->id); ?>/edit">Edit</a></td>
                            <td>
                                <form action="/company/<?php echo e($c->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>                  
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/company/index.blade.php */ ?>