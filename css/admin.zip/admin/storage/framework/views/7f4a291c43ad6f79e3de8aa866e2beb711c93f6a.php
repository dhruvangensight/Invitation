<?php $__env->startSection('section-title', 'Products'); ?>

<?php $__env->startSection('section-button'); ?>
    <a class="btn btn-sm btn-outline-secondary" href="/product/create">
        Add new
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md">            
            <form class="mb-3" action="<?php echo e(URL::to('/')); ?>/product/filter" method="GET">
                <div class="form-row mb-4">
                    <div class="col">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Product Name" value="<?php echo e(Request::get('name')); ?>">
                    </div>    
                    <div class="col">
                        <input type="text" class="form-control" id="model" name="model" placeholder="Product Model" value="<?php echo e(Request::get('model')); ?>">
                    </div>
                    <div class="col">    
                        <input type="text" class="form-control" id="company" name="company" placeholder="Product Company" value="<?php echo e(Request::get('company')); ?>">
                    </div>    
                </div>     
                <div class="form-row mb-4">
                    <div class="col-md">
                        <div class="form-row">
                            <div class="col">    
                                <input type="text" class="form-control" id="price_min" name="price_min" placeholder="Product Min" value="<?php echo e(Request::get('price_min')); ?>">
                            </div>    
                            <div class="col">
                                <input type="text" class="form-control" id="price_max" name="price_max" placeholder="Product Max" value="<?php echo e(Request::get('price_max')); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-row">
                            <div class="col">    
                                <input type="text" class="form-control" id="qty_min" name="qty_min" placeholder="Quantity Min" value="<?php echo e(Request::get('qty_min')); ?>">
                            </div>    
                            <div class="col">
                                <input type="text" class="form-control" id="qty_max" name="qty_max" placeholder="Quantity Max" value="<?php echo e(Request::get('qty_max')); ?>">
                            </div>
                        </div>
                    </div>
                </div>           
                
                <button type="submit" class="btn btn-primary mb-2">Submit</button>
                <a href="/product" class="btn btn-primary mb-2">Reset</a>
            </form>

            <nav class="navbar navbar-expand-lg navbar-light bg-light">   
                <?php echo e($product->render()); ?>

            </nav>

            <a href="<?php echo e(url('product/pdf')); ?>" class="btn btn-success mb-2">Export PDF</a>

            <table class="table table-hover" id="products">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Model</th>
                        <th scope="col">Price</th>
                        <th scope="col">Qty</th>
                        <th scope="col">Company</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e(Request::get('page') ? $loop->iteration + (Request::get('page') - 1) * 15 :  $loop->iteration); ?></th>
                            <td><?php echo e($p->name); ?></td>
                            <td><?php echo $p->description; ?></td>
                            <td><?php echo $p->model; ?></td>
                            <td><?php echo $p->price; ?></td>
                            <td><?php echo $p->quantity; ?></td>
                            <td><?php echo $p->company->name; ?></td>
                            <td>
                                <a class="btn btn-secondary btn-sm" href="/product/<?php echo e($p->id); ?>/edit">Edit</a></td>
                            <td>
                                <form action="/product/<?php echo e($p->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>    
            
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <?php echo e($product->render()); ?>

            </nav>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/product/index.blade.php */ ?>