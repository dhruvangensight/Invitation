<?php $__env->startSection('section-title', 'Customers'); ?>

<?php $__env->startSection('section-button'); ?>
    <a class="btn btn-sm btn-outline-secondary" href="/customer">Back to Customers</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md">  
            <form action="/customer/<?php echo e($customer->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" placeholder="Customer Name" value="<?php echo e(old('name', $customer->name)); ?>">
                    <?php if($errors->has('name')): ?> <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div> <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="email" name="email" placeholder="Customer email" value="<?php echo e(old('email', $customer->email)); ?>">
                    <?php if($errors->has('email')): ?> <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div> <?php endif; ?>
                </div>


                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" id="phone" name="phone" placeholder="Customer phone" value="<?php echo e(old('phone', $customer->phone)); ?>">
                    <?php if($errors->has('phone')): ?> <div class="invalid-feedback"><?php echo e($errors->first('phone')); ?></div> <?php endif; ?>
                </div>


                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" id="address" name="address" placeholder="Customer address" value="<?php echo e(old('address', $customer->address)); ?>">
                    <?php if($errors->has('address')): ?> <div class="invalid-feedback"><?php echo e($errors->first('address')); ?></div> <?php endif; ?>
                </div>
                    
                <div class="form-group">    
                    <label for="notes">Notes</label>
                    <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" id="notes" name="notes" placeholder="Customer notes"><?php echo e(old('notes', $customer->notes)); ?></textarea>
                    <?php if($errors->has('notes')): ?> <div class="invalid-feedback"><?php echo e($errors->first('notes')); ?></div> <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Add Customer</button>
            </form>  
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/customer/update.blade.php */ ?>