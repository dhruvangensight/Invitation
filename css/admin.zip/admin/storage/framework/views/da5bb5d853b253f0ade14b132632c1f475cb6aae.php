<?php $__env->startSection('section-title', 'Products'); ?>

<?php $__env->startSection('section-button'); ?>
    <a class="btn btn-sm btn-outline-secondary" href="/product">Back to Products</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md">      
            <form action="/product/<?php echo e($product->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="form-group">
                    <label for="company">Company</label>
                    <select class="form-control <?php echo e($errors->has('company_id') ? 'is-invalid' : ''); ?>" id="company" name="company_id">
                        <option value="" selected>Choose Company</option> 
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(($id === $product->company_id) ? 'selected' : ''); ?>><?php echo e($name); ?></option>      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('company_id')): ?> <div class="invalid-feedback"><?php echo e($errors->first('company_id')); ?></div> <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" placeholder="Product Name" value="<?php echo e(old('name', $product->name)); ?>">
                    <?php if($errors->has('name')): ?> <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div> <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="description" name="description" placeholder="Product Description"><?php echo e(old('description', $product->description)); ?></textarea>
                    <?php if($errors->has('description')): ?> <div class="invalid-feedback"><?php echo e($errors->first('description')); ?></div> <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="model">Model</label>
                    <input type="text" class="form-control <?php echo e($errors->has('model') ? 'is-invalid' : ''); ?>" id="model" name="model" placeholder="Product Model" value="<?php echo e(old('model', $product->model)); ?>">
                    <?php if($errors->has('model')): ?> <div class="invalid-feedback"><?php echo e($errors->first('model')); ?></div> <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="text" class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" id="price" name="price" placeholder="Product Price" value="<?php echo e(old('price', $product->price)); ?>">
                    <?php if($errors->has('price')): ?> <div class="invalid-feedback"><?php echo e($errors->first('price')); ?></div> <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="text" class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" id="quantity" name="quantity" placeholder="Product Quantity" value="<?php echo e(old('quantity', $product->quantity)); ?>">
                    <?php if($errors->has('quantity')): ?> <div class="invalid-feedback"><?php echo e($errors->first('quantity')); ?></div> <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-primary">Add Product</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/product/update.blade.php */ ?>