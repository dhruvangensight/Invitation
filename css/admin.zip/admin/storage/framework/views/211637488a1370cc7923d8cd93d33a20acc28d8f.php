<?php $__env->startSection('content'); ?>
<h1 class="text-center display-4 my-5">Product List</h1>
<div class="container">
    <table class="table table-hover" id="products">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Model</th>
                <th scope="col">Price</th>
                <th scope="col">Qty</th>
                <th scope="col">Company</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e(Request::get('page') ? $loop->iteration + (Request::get('page') - 1) * 15 :  $loop->iteration); ?></th>
                    <td><?php echo e($p->name); ?></td>
                    <td><?php echo $p->description; ?></td>
                    <td><?php echo $p->model; ?></td>
                    <td><?php echo $p->price; ?></td>
                    <td><?php echo $p->quantity; ?></td>
                    <td><?php echo $p->company->name; ?></td>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>  
</div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/product/export.blade.php */ ?>