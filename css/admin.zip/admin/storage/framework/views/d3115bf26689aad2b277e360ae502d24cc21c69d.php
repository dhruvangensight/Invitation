<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
            <?php echo e($slot); ?>

        </a>
    </td>
</tr>

<?php /* E:\xampp\htdocs\laravel\admin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/header.blade.php */ ?>