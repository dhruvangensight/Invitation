<?php $__env->startSection('section-title', 'Companies'); ?>

<?php $__env->startSection('section-button'); ?>
    <a class="btn btn-sm btn-outline-secondary" href="/company">Back to Companies</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md">       
            <form action="/company" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" name="name" placeholder="Company Name" value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?> <div class="invalid-feedback"><?php echo e($errors->first('name')); ?></div> <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" id="description" name="description" placeholder="Company Description"><?php echo e(old('description')); ?></textarea>
                    <?php if($errors->has('description')): ?> <div class="invalid-feedback"><?php echo e($errors->first('description')); ?></div> <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Add Company</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/company/create.blade.php */ ?>