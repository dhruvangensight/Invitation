<?php $__env->startSection('section-title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/home.blade.php */ ?>