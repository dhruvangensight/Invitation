<?php $__env->startSection('section-title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md">
            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <form action="/profile/<?php echo e($user[0]->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo e($user[0]->name); ?>">
                </div>
    
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control <?php echo e(($user[0]->email_verified_at == null) ? 'is-invalid' : ''); ?>"  id="email" name="email" placeholder="email" value="<?php echo e($user[0]->email); ?>" disabled>
                    <?php if($user[0]->email_verified_at == null): ?>
                        <div class="invalid-feedback">Please verify your email</div>
                    <?php endif; ?>
                </div>
    
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" value="<?php echo e($user[0]->phone); ?>">
                </div>
    
                <button type="submit" class="btn btn-primary">Update</button>
    
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* E:\xampp\htdocs\laravel\admin\resources\views/auth/profile/index.blade.php */ ?>