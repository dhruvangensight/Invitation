$(document).ready(function () {
    if ($('#description').length > 0) {
        ClassicEditor
            .create(document.querySelector('#description'))
            .catch(error => {
                console.error(error);
            });
    }
});