@extends('layouts.home')


@section('section-title', 'Companies')

@section('section-button')
    <a class="btn btn-sm btn-outline-secondary" href="/company/create">
        Add new
    </a>
@endsection

@section('content')
    <div class="row">
        <div class="col-md">
            <table class="table table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($company as $c)
                        <tr>
                        <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $c->name }}</td>
                            <td>{!! $c->description !!}</td>
                            <td>
                                <a class="btn btn-secondary btn-sm" href="/company/{{ $c->id }}/edit">Edit</a></td>
                            <td>
                                <form action="/company/{{ $c->id }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>    
                    @endforeach
                </tbody>
            </table>                  
        </div>
    </div>
@endsection

