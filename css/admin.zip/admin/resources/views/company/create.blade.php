@extends('layouts.home')


@section('section-title', 'Companies')

@section('section-button')
    <a class="btn btn-sm btn-outline-secondary" href="/company">Back to Companies</a>
@endsection

@section('content')
    <div class="row">
        <div class="col-md">       
            <form action="/company" method="POST">
                @csrf
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" id="name" name="name" placeholder="Company Name" value="{{ old('name') }}">
                    @if ($errors->has('name')) <div class="invalid-feedback">{{ $errors->first('name') }}</div> @endif
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control {{ $errors->has('description') ? 'is-invalid' : '' }}" id="description" name="description" placeholder="Company Description">{{ old('description') }}</textarea>
                    @if ($errors->has('description')) <div class="invalid-feedback">{{ $errors->first('description') }}</div> @endif
                </div>
                <button type="submit" class="btn btn-primary">Add Company</button>
            </form>
        </div>
    </div>
@endsection

