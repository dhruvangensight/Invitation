@extends('layouts.home')


@section('section-title', 'Customers')

@section('section-button')
    <a class="btn btn-sm btn-outline-secondary" href="/customer/create">
        Add new
    </a>
@endsection

@section('content')
    <div class="row">
        <div class="col-md">
            <table class="table table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Address</th>
                        <th scope="col">Notes</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($customer as $c)
                        <tr>
                        <th scope="row">{{ $loop->iteration }}</th>
                            <td>{{ $c->name }}</td>
                            <td>{{ $c->email }}</td>
                            <td>{{ $c->phone }}</td>
                            <td>{{ $c->address }}</td>
                            <td>{!! $c->notes !!}</td>
                            <td>
                                <a class="btn btn-secondary btn-sm" href="/customer/{{ $c->id }}/edit">Edit</a></td>
                            <td>
                                <form action="/customer/{{ $c->id }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>    
                    @endforeach
                </tbody>
            </table>                  
        </div>
    </div>
@endsection

