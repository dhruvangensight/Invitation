@extends('layouts.home')

@section('section-title', 'Customers')

@section('section-button')
    <a class="btn btn-sm btn-outline-secondary" href="/customer">Back to Customers</a>
@endsection

@section('content')
    <div class="row">
        <div class="col-md">  
            <form action="/customer/{{$customer->id}}" method="POST">
                @csrf
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" id="name" name="name" placeholder="Customer Name" value="{{ old('name', $customer->name) }}">
                    @if ($errors->has('name')) <div class="invalid-feedback">{{ $errors->first('name') }}</div> @endif
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" id="email" name="email" placeholder="Customer email" value="{{ old('email', $customer->email) }}">
                    @if ($errors->has('email')) <div class="invalid-feedback">{{ $errors->first('email') }}</div> @endif
                </div>


                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control {{ $errors->has('phone') ? 'is-invalid' : '' }}" id="phone" name="phone" placeholder="Customer phone" value="{{ old('phone', $customer->phone) }}">
                    @if ($errors->has('phone')) <div class="invalid-feedback">{{ $errors->first('phone') }}</div> @endif
                </div>


                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" id="address" name="address" placeholder="Customer address" value="{{ old('address', $customer->address) }}">
                    @if ($errors->has('address')) <div class="invalid-feedback">{{ $errors->first('address') }}</div> @endif
                </div>
                    
                <div class="form-group">    
                    <label for="notes">Notes</label>
                    <textarea class="form-control {{ $errors->has('notes') ? 'is-invalid' : '' }}" id="notes" name="notes" placeholder="Customer notes">{{ old('notes', $customer->notes) }}</textarea>
                    @if ($errors->has('notes')) <div class="invalid-feedback">{{ $errors->first('notes') }}</div> @endif
                </div>
                <button type="submit" class="btn btn-primary">Add Customer</button>
            </form>  
        </div>
    </div>
@endsection

