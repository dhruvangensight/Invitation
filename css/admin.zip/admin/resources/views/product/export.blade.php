@extends('layouts.print')

@section('content')
<h1 class="text-center display-4 my-5">Product List</h1>
<div class="container">
    <table class="table table-hover" id="products">
        <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Model</th>
                <th scope="col">Price</th>
                <th scope="col">Qty</th>
                <th scope="col">Company</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($products as $p)
                <tr>
                <th scope="row">{{ Request::get('page') ? $loop->iteration + (Request::get('page') - 1) * 15 :  $loop->iteration }}</th>
                    <td>{{ $p->name }}</td>
                    <td>{!! $p->description !!}</td>
                    <td>{!! $p->model !!}</td>
                    <td>{!! $p->price !!}</td>
                    <td>{!! $p->quantity !!}</td>
                    <td>{!! $p->company->name !!}</td>
                </tr> 
            @endforeach
        </tbody>
    </table>  
</div>
      
@endsection
