@extends('layouts.home')


@section('section-title', 'Products')

@section('section-button')
    <a class="btn btn-sm btn-outline-secondary" href="/product">Back to Companies</a>
@endsection

@section('content')
    <div class="row">
        <div class="col-md">      
            <form action="/product" method="POST">
                @csrf
                <div class="form-group">
                    <label for="company">Company</label>
                    <select class="form-control {{ $errors->has('company_id') ? 'is-invalid' : '' }}" id="company" name="company_id" data-live-search="true" data-width="fit">
                        <option value="" selected>Choose Company</option> 
                        @foreach ($companies as $name => $id)
                            <option value="{{ $id }}">{{ $name }}</option>      
                        @endforeach
                    </select>
                    @if ($errors->has('company_id')) <div class="invalid-feedback">{{ $errors->first('company_id') }}</div> @endif
                </div>

                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" id="name" name="name" placeholder="Product Name" value="{{ old('name') }}">
                    @if ($errors->has('name')) <div class="invalid-feedback">{{ $errors->first('name') }}</div> @endif
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control {{ $errors->has('description') ? 'is-invalid' : '' }}" id="description" name="description" placeholder="Product Description">{{ old('description') }}</textarea>
                    @if ($errors->has('description')) <div class="invalid-feedback">{{ $errors->first('description') }}</div> @endif
                </div>

                <div class="form-group">
                    <label for="model">Model</label>
                    <input type="text" class="form-control {{ $errors->has('model') ? 'is-invalid' : '' }}" id="model" name="model" placeholder="Product Model" value="{{ old('model') }}">
                    @if ($errors->has('model')) <div class="invalid-feedback">{{ $errors->first('model') }}</div> @endif
                </div>

                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="text" class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}" id="price" name="price" placeholder="Product Price" value="{{ old('price') }}">
                    @if ($errors->has('price')) <div class="invalid-feedback">{{ $errors->first('price') }}</div> @endif
                </div>

                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="text" class="form-control {{ $errors->has('quantity') ? 'is-invalid' : '' }}" id="quantity" name="quantity" placeholder="Product Quantity" value="{{ old('quantity') }}">
                    @if ($errors->has('quantity')) <div class="invalid-feedback">{{ $errors->first('quantity') }}</div> @endif
                </div>

                <button type="submit" class="btn btn-primary">Add Product</button>
            </form>
        </div>
    </div>
@endsection

