@extends('layouts.home')


@section('section-title', 'Products')

@section('section-button')
    <a class="btn btn-sm btn-outline-secondary" href="/product/create">
        Add new
    </a>
@endsection

@section('content')
    <div class="row">
        <div class="col-md">            
            <form class="mb-3" action="{{URL::to('/')}}/product/filter" method="GET">
                <div class="form-row mb-4">
                    <div class="col">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Product Name" value="{{ Request::get('name') }}">
                    </div>    
                    <div class="col">
                        <input type="text" class="form-control" id="model" name="model" placeholder="Product Model" value="{{ Request::get('model') }}">
                    </div>
                    <div class="col">    
                        <input type="text" class="form-control" id="company" name="company" placeholder="Product Company" value="{{ Request::get('company') }}">
                    </div>    
                </div>     
                <div class="form-row mb-4">
                    <div class="col-md">
                        <div class="form-row">
                            <div class="col">    
                                <input type="text" class="form-control" id="price_min" name="price_min" placeholder="Product Min" value="{{ Request::get('price_min') }}">
                            </div>    
                            <div class="col">
                                <input type="text" class="form-control" id="price_max" name="price_max" placeholder="Product Max" value="{{ Request::get('price_max') }}">
                            </div>
                        </div>
                    </div>
                    <div class="col-md">
                        <div class="form-row">
                            <div class="col">    
                                <input type="text" class="form-control" id="qty_min" name="qty_min" placeholder="Quantity Min" value="{{ Request::get('qty_min') }}">
                            </div>    
                            <div class="col">
                                <input type="text" class="form-control" id="qty_max" name="qty_max" placeholder="Quantity Max" value="{{ Request::get('qty_max') }}">
                            </div>
                        </div>
                    </div>
                </div>           
                
                <button type="submit" class="btn btn-primary mb-2">Submit</button>
                <a href="/product" class="btn btn-primary mb-2">Reset</a>
            </form>

            <nav class="navbar navbar-expand-lg navbar-light bg-light">   
                {{ $product->render() }}
            </nav>

            <a href="{{ url('product/pdf') }}" class="btn btn-success mb-2">Export PDF</a>

            <table class="table table-hover" id="products">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Model</th>
                        <th scope="col">Price</th>
                        <th scope="col">Qty</th>
                        <th scope="col">Company</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($product as $p)
                        <tr>
                        <th scope="row">{{ Request::get('page') ? $loop->iteration + (Request::get('page') - 1) * 15 :  $loop->iteration }}</th>
                            <td>{{ $p->name }}</td>
                            <td>{!! $p->description !!}</td>
                            <td>{!! $p->model !!}</td>
                            <td>{!! $p->price !!}</td>
                            <td>{!! $p->quantity !!}</td>
                            <td>{!! $p->company->name !!}</td>
                            <td>
                                <a class="btn btn-secondary btn-sm" href="/product/{{ $p->id }}/edit">Edit</a></td>
                            <td>
                                <form action="/product/{{ $p->id }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>    
                    @endforeach
                </tbody>
            </table>    
            
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                {{ $product->render() }}
            </nav>

        </div>
    </div>
@endsection

