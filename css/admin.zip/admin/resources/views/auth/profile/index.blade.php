@extends('layouts.home')
@section('section-title', 'Profile')

@section('content')
    <div class="row">
        <div class="col-md">
            @if (session('message'))
                <div class="alert alert-success">
                    {{ session('message') }}
                </div>
            @endif
            <form action="/profile/{{$user[0]->id}}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PATCH')
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="{{$user[0]->name}}">
                </div>
    
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control {{ ($user[0]->email_verified_at == null) ? 'is-invalid' : '' }}"  id="email" name="email" placeholder="email" value="{{$user[0]->email}}" disabled>
                    @if ($user[0]->email_verified_at == null)
                        <div class="invalid-feedback">Please verify your email</div>
                    @endif
                </div>
    
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" value="{{$user[0]->phone}}">
                </div>
    
                <button type="submit" class="btn btn-primary">Update</button>
    
            </form>
        </div>
    </div>
@endsection

